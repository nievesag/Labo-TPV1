#include "checkML.h"
#include "GameObject.h"

GameObject::~GameObject() {}

void GameObject::render(SDL_Rect destRect) const {}

void GameObject::save(ostream& out) const {}